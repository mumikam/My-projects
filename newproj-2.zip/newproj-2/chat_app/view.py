from django.shortcuts import redirect
from django.contrib.auth.views import login, logout

def login_redirect(request):
    return redirect('alpha/register')