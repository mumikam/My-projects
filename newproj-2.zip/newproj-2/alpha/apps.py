from django.apps import AppConfig


class AlphaConfig(AppConfig):
    name = 'alpha'
