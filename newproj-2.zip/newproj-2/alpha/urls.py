from django.conf.urls import url
from . import views
from django.contrib.auth.views import login, logout


urlpatterns = [
	url(r'^$', views.home, name='home'),
    url(r'^login/$', login, {'template_name': 'alpha/login.html'}, name='login'),
    url(r'^logout/$', logout, {'template_name': 'alpha/logout.html'}, name='logout'),
    url(r'^register/$', views.register, name='register'),
    url(r'^home/$', views.Home, name='text'), 
    url(r'^profile/edit/$', views.edit_profile, name='edit_profile'),
]