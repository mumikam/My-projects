from django.shortcuts import render, HttpResponse, redirect
from django.urls import reverse
from alpha.forms import (
    RegistrationForm,
    EditProfileForm
)
from django.contrib.auth import authenticate, logout, login
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from chat_app import settings
from django.views.decorators.csrf import csrf_exempt
from .models import Chat
from .models import UserProfile
from django.contrib.auth.forms import UserCreationForm
from . import views

@csrf_exempt
def Home(request):
    c = Chat.objects.all()
    return render(request, "alpha/home.html", {'home': 'active', 'chat': c})

@csrf_exempt
def Post(request):
    if request.method == "POST":
        msg = request.POST.get('msgbox', None)
        c = Chat(user=request.user, message=msg)
        if msg != '':
            c.save()
        return JsonResponse({ 'msg': msg, 'user': c.user.username })
    else:
        return HttpResponse('Request must be POST.')
@csrf_exempt
def Messages(request):
    c = Chat.objects.all()
    return render(request, 'alpha/messages.html', {'chat': c})

def home(request):
    numbers = [1,2,3,4,5]
    name = 'Assina'
    args = {'myName': name, 'numbers': numbers}
    return render(request, 'alpha/main.html', args)

def register(request):
    if request.method =='POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect(reverse('alpha:home'))
    else:
        form = RegistrationForm()

        args = {'form': form}
        return render(request, 'alpha/reg_form.html', args)
def edit_profile(request):
    if request.method == 'POST':
        form = EditProfileForm(request.POST, instance=request.user)

        if form.is_valid():
            form.save()
            return redirect(reverse('alpha:view_profile'))
    else:
        form = EditProfileForm(instance=request.user)
        args = {'form': form}
        return render(request, 'alpha/edit_profile.html', args)
